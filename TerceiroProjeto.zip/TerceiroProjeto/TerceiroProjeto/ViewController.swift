//
//  ViewController.swift
//  TerceiroProjeto
//
//  Created by Administrador on 16/03/19.
//  Copyright © 2019 Administrador. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var senhaUser: UITextField!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func btnLogar(_ sender: Any) {
        
        if userName.text == nil {
            userName.text = "Preencher o campo!"
        } else if senhaUser.text == nil{
            userName.text = "Preencher a senha!"
        } else if !(senhaUser.text == "root" && userName.text == "root"){
            userName.text = "Usuário e/ou senha inválidos"
        }
        
    }
    
    @IBAction func btnAjuda(_ sender: Any) {
        
    }
    
}

