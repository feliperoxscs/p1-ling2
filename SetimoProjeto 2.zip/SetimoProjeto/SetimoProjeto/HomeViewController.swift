//
//  HomeViewController.swift
//  SetimoProjeto
//
//  Created by Administrador on 01/06/19.
//  Copyright © 2019 Administrador. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBAction func sobre(_ sender: Any) {
        performSegue(withIdentifier: "sobre", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func scan(_ sender: Any) {
        performSegue(withIdentifier: "scanear", sender: self)
    }
    
    
    @IBAction func gerar(_ sender: Any) {
        performSegue(withIdentifier: "gerar", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
