//
//  ViewController.swift
//  SetimoProjeto
//
//  Created by Administrador on 11/05/19.
//  Copyright © 2019 Administrador. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var user: UITextField!
    @IBAction func troca(_ sender: Any) {
        if user.text == "root"{
            performSegue(withIdentifier: "teste", sender: self)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}

